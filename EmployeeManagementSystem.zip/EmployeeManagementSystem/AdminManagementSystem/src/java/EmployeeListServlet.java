import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;

@WebServlet("/EmployeeListServlet")
public class EmployeeListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM employees");
            ResultSet rs = ps.executeQuery();
            
            ArrayList<String[]> employees = new ArrayList<>();
            while (rs.next()) {
                String[] emp = {
                    String.valueOf(rs.getInt("id")),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("position"),
                    String.valueOf(rs.getDouble("salary")),
                    rs.getString("department"),
                    rs.getString("hire_date")
                };
                employees.add(emp);
            }
            
            request.setAttribute("employees", employees);
            System.out.println("Employee data being sent to JSP: " + employees.size());
            request.getRequestDispatcher("employee-list.jsp").forward(request, response);
        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
