import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/DashboardDataServlet")
public class DashboardDataServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try (Connection con = DatabaseConnection.getConnection()) {

            // Fetch department stats
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT department, COUNT(*) FROM employees GROUP BY department");
            ResultSet rs1 = ps1.executeQuery();
            List<String> departments = new ArrayList<>();
            List<Integer> departmentCounts = new ArrayList<>();
            while (rs1.next()) {
                departments.add(rs1.getString(1));
                departmentCounts.add(rs1.getInt(2));
            }

            // Fetch hiring trends
            PreparedStatement ps2 = con.prepareStatement(
                "SELECT DATE_FORMAT(hire_date, '%b %Y') AS month, COUNT(*) AS count " +
                "FROM employees " +
                "WHERE hire_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) " +
                "GROUP BY DATE_FORMAT(hire_date, '%b %Y') " +
                "ORDER BY MIN(hire_date)"
            );
            ResultSet rs2 = ps2.executeQuery();
            List<String> months = new ArrayList<>();
            List<Integer> hires = new ArrayList<>();
            while (rs2.next()) {
                months.add(rs2.getString("month"));
                hires.add(rs2.getInt("count"));
            }

            // Set attributes
            request.setAttribute("departments", departments);
            request.setAttribute("departmentCounts", departmentCounts);
            request.setAttribute("months", months);
            request.setAttribute("hires", hires);

            // Debugging output
            System.out.println("Departments loaded: " + departments.size());
            System.out.println("Months loaded: " + months.size());

            // Forward to dashboard.jsp
            request.getRequestDispatcher("dashboard.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Dashboard Error: " + e.getMessage());
        }
    }
}
