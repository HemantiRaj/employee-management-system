import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpdateEmployeeServlet")
public class UpdateEmployeeServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String position = request.getParameter("position");
        double salary = Double.parseDouble(request.getParameter("salary"));
        String department = request.getParameter("department");
        String hire_date = request.getParameter("hire_date");

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("UPDATE employees SET name=?, email=?, position=?, salary=?, department=?, hire_date=? WHERE id=?");
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, position);
            ps.setDouble(4, salary);
            ps.setString(5, department);
            ps.setString(6, hire_date);
            ps.setInt(7, id);
            
            
            
            ps.executeUpdate();
            response.sendRedirect("EmployeeListServlet");
        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
